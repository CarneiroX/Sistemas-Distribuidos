package calculadorarmi;

import java.rmi.Naming;
import java.util.Scanner;

public class CalcClient {
    public static void main(String args[]){
        System.out.println("Calculadora");
        System.out.println("");
        System.out.println(". Digite 1 para fazer um Cálculo de Adição");
        System.out.println(". Digite 2 para fazer um Cálculo de Subtração");
        System.out.println(". Digite 3 para fazer um Cálculo de Multiplicação");
        System.out.println(". Digite 4 para fazer um Cálculo de Divisão");
        System.out.println("");
        System.out.println("Digite sua Opção: ");
        
        Scanner sc = new Scanner(System.in);
        try{
            CalcInterface c = (CalcInterface)Naming.lookup("//localhost/Calc");
            int escolha = sc.nextInt();
            int x,y;
            switch(escolha){
                case 1:{
                    System.out.println("Digite o Primeiro Valor: ");
                    x=sc.nextInt();
                    System.out.println("Digite o Segundo Valor: ");
                    y=sc.nextInt();
                    System.out.println("O Resultado é : "+c.add(x, y));
                    break;
                }
                case 2:{
                    System.out.println("Digite o Primeiro Valor: ");
                    x=sc.nextInt();
                    System.out.println("Digite o Segundo Valor: ");
                    y=sc.nextInt();
                    System.out.println("O Resultado é : "+c.sub(x, y));
                    break;
                }
                case 3:{
                    System.out.println("Digite o Primeiro Valor: ");
                    x=sc.nextInt();
                    System.out.println("Digite o Segundo Valor: ");
                    y=sc.nextInt();
                    System.out.println("O Resultado é : "+c.mul(x, y));
                    break;
                }
                case 4:{
                    System.out.println("Digite o Primeiro Valor: ");
                    x=sc.nextInt();
                    System.out.println("Digite o Segundo Valor: ");
                    y=sc.nextInt();
                    System.out.println("O Resultado é : "+c.div(x, y));
                    break;
                }
            }
        }catch(Exception e){
            System.out.println(e);
        }
    }
}
