# Simple-RMI-Calculator

This is a simple application to demonstrate the flow of Java RMI API.
visit https://kalinduwijekoon.blogspot.com/2018/12/rmi-intro.html for get an idea about Java RMI API.


I developed this application in NetBeans IDE, so if you are using NetBeans, directly import this project, 
or you can simply view the source code in any text editor and rewrite it on your IDE.

Some mathematical operations are supported only for simple values since I developed this application for demonstration purposes.
So fraction operations are not supported.
Anyways you can upgrade the functionalities of the application as you wish.


When running the application,
----------------------------
  First you need to run the "CalcServer.java" class in according to start the server.
  
  And then run the "CalcClient.java" class to begin.



All operations are running on the command line.


Feel free to contact me via my email for any inquiries :) :) 
